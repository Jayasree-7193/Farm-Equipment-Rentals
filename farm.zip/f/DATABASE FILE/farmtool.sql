-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2021 at 04:49 PM
-- Server version: 5.6.21
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `carrentalp`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE IF NOT EXISTS `tools` (
`tool_id` varchar(20) NOT NULL,
  `tool_name` varchar(50) NOT NULL,
  `tool_type` varchar(50) NOT NULL,
  `tool_img` varchar(50) DEFAULT 'NA',
  `userguide_price_per_hr` float NOT NULL,
  `non_userguide_price_per_hr` float NOT NULL,
  `userguide_price_per_day` float NOT NULL,
  `non_userguide_price_per_day` float NOT NULL,
  `tool_availability` varchar(10) NOT NULL,
  `tool_text` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`tool_id`, `tool_name`, `tool_type`, `tool_img`, `userguide_price_per_hr`, `non_userguide_price_per_hr`, `userguide_price_per_day`, `non_userguide_price_per_day`, `tool_availability` , `tool_text`) VALUES
('ME1', 'Axe', 'Mechanical', 'assets/img/tools/axe.jpg', 36, 26, 520, 260, 'yes','Hand tool used for chopping, splitting, chipping, and piercing'),
('ME2', 'Hoe', 'Mechanical', 'assets/img/tools/hoe.jpg', 22, 12, 290, 140, 'yes','Commonly used in gardening and horticulture to loosen soil and chop weeds'),
('ME3', 'Crowbar', 'Mechanical', 'assets/img/tools/crowbar.jpg', 39, 30, 690, 590, 'yes','Used for digging big holes and for digging out big stones and stumps'),
('ME4', 'Pitchfork', 'Mechanical', 'assets/img/tools/pitchfork.jpg', 45, 30, 720, 520, 'yes','Used to lift and pitch or throw loose material, such as hay, straw, manure, or leaves'),
('ME5', 'Rake', 'Mechanical', 'assets/img/tools/rake.jpg', 21, 13, 380, 260, 'yes','Used for scooping, scraping, gathering, or leveling materials, such as soil, mulch, or leaves'),
('ME6', 'Shears', 'Mechanical', 'assets/img/tools/shears.jpg', 14, 12, 280, 240, 'no','Used to prune hard branches of trees and shrubs, sometimes up to two centimetres thick'),
('ME7', 'Shovel', 'Mechanical', 'assets/img/tools/shovel.jpg', 36, 26, 600, 460, 'yes','Helps with digging and transplanting soil, making shallow trenches, and in removing dirt or debris'),
('ME8', 'Sickle', 'Mechanical', 'assets/img/tools/sickle.jpg', 20, 12, 290, 140, 'yes','Used for the harvesting of vegetables, cereal crops and cutting of the grass and other vegetative matters'),
('ME9', 'Spade', 'Mechanical', 'assets/img/tools/spade.jpg', 22, 15, 285, 140, 'yes','Used for digging comprising a blade – typically curved and more pointed'),
('ME10', 'Wheelbarrow', 'Mechanical', 'assets/img/tools/wheelbarrow.jpg', 15, 13, 300, 260, 'yes','A small object that easily used single-handed to transport the gardens gardening material'),
('MA11', 'Seeddrill', 'Machinery', 'assets/img/tools/drill.jpg', 16, 14, 320, 280, 'yes',' A device used in agriculture that sows seeds for crops by positioning them in the soil and burying them to a specific depth'),
('MA12', 'Sprayer', 'Machinery', 'assets/img/tools/sprayer.jpg', 39, 29, 610, 438, 'yes','A device used in agriculture used to spray liquids like water, insecticides, and pesticides in agriculture');

-- --------------------------------------------------------

--
-- Table structure for table `clienttools`
--

CREATE TABLE IF NOT EXISTS `clienttools` (
  `tool_id` varchar(20) NOT NULL,
  `client_username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clienttools`
--

INSERT INTO `clienttools` (`tool_id`, `client_username`) VALUES
('ME1', 'harry'),
('ME3', 'harry'),
('ME7', 'harry'),
('ME8', 'harry'),
('ME9', 'harry'),
('MA11', 'harry'),
('MA12', 'harry'),
('ME2', 'jenny'),
('ME4', 'jenny'),
('ME6', 'jenny'),
('ME10', 'jenny'),
('ME5', 'jenny');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `client_username` varchar(50) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_phone` varchar(15) NOT NULL,
  `client_email` varchar(25) NOT NULL,
  `client_address` varchar(50) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `client_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_username`, `client_name`, `client_phone`, `client_email`, `client_address`, `client_password`) VALUES
('harry', 'Harry Den', '9876543210', 'harryden@gmail.com', '2477  Harley Vincent Drive', 'password'),
('jenny', 'Jeniffer Washington', '7850000069', 'washjeni@gmail.com', '4139  Mesa Drive', 'jenny'),
('tom', 'Tommy Doee', '900696969', 'tom@gmail.com', '4645  Dawson Drive', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customer_username` varchar(50) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `customer_email` varchar(25) NOT NULL,
  `customer_address` varchar(50) NOT NULL,
  `customer_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_username`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `customer_password`) VALUES
('antonio', 'Antonio M', '0785556580', 'antony@gmail.com', '2677  Burton Avenue', 'password'),
('christine', 'Christine', '8544444444', 'chr@gmail.com', '3701  Fairway Drive', 'password'),
('ethan', 'Ethan Hawk', '69741111110', 'thisisethan@gmail.com', '4554  Rowes Lane', 'password'),
('james', 'James Washington', '0258786969', 'james@gmail.com', '2316  Mayo Street', 'password'),
('lucas', 'Lucas Rhoades', '7003658500', 'lucas@gmail.com', '2737  Fowler Avenue', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

CREATE TABLE IF NOT EXISTS `agent` (
`agent_id` varchar(20) NOT NULL,
  `agent_name` varchar(50) NOT NULL,
  `agent_mailid` varchar(50) NOT NULL,
  `agent_phone` varchar(15) NOT NULL,
  `agent_address` varchar(50) NOT NULL,
  `agent_gender` varchar(10) NOT NULL,
  `client_username` varchar(50) NOT NULL,
  `agent_availability` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`agent_id`, `agent_name`, `agent_mailid`, `agent_phone`, `agent_address`, `agent_gender`, `client_username`, `agent_availability`) VALUES
('AG1', 'Bruno Den', 'bruno@gmail.com ', '9547863157', '1782  Vineyard Drive', 'Male', 'harry', 'yes'),
('AG2', 'Will Williams', 'will@gmail.com ', '9147523684', '4354  Hillcrest Drive', 'Male', 'harry', 'yes'),
('AG3', 'Steeve Rogers', 'steeve@gmail.com ', '9147523682', '1506  Skinner Hollow Road', 'Male', 'harry', 'yes'),
('AG4', 'Ivy', '04316015965 ', 'ivy@gmail.com', '4680  Wayside Lane', 'Female', 'jenny', 'no'),
('AG5', 'Pamela C Benson', 'pamela@gmail.com ', '7584960123', 'Urkey Pen Road', 'Female', 'jenny', 'yes'),
('AG6', 'Billy Williams', 'billy@gmail.com ', '8421025476', '2898  Oxford Court', 'Male', 'tom', 'yes'),
('AG7', 'Nicolas', 'nicolas@gmail.com', '7541023695', 'Breezewood Court', 'Male', 'harry', 'yes'),
('AG8', 'Stephen Strange', 'stephen@gmail.com', '5215557850', 'Fairview Street12', 'Male', 'jenny', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `name` varchar(20) NOT NULL,
  `e_mail` varchar(30) NOT NULL,
  `message` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `e_mail`, `message`) VALUES
('Nikhil', 'nikhil@gmail.com', 'Hope this works.');

-- --------------------------------------------------------

--
-- Table structure for table `rentedtools`
--

CREATE TABLE IF NOT EXISTS `rentedtools` (
`id` int(100) NOT NULL,
  `customer_username` varchar(50) NOT NULL,
  `tool_id` varchar(20) NOT NULL,
  `agent_id` int(20) NOT NULL,
  `booking_date` date NOT NULL,
  `rent_start_date` date NOT NULL,
  `rent_end_date` date NOT NULL,
  `tool_return_date` date DEFAULT NULL,
  `fare` double NOT NULL,
  `charge_type` varchar(25) NOT NULL DEFAULT 'days',
  `hours` double DEFAULT NULL,
  `no_of_days` int(50) DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `return_status` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=574681260 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rentedtools`
--

INSERT INTO `rentedtools` (`id`, `customer_username`, `tool_id`, `agent_id`, `booking_date`, `rent_start_date`, `rent_end_date`, `tool_return_date`, `fare`, `charge_type`, `hours`, `no_of_days`, `total_amount`, `return_status`) VALUES
(574681245, 'ethan', 'ME4', 'AG2', '2018-07-18', '2018-07-01', '2018-07-02', '2018-07-18', 11, 'hr', 22, 1, 5884, 'R'),
(574681246, 'james', 'ME6', 'AG6', '2018-07-18', '2018-06-01', '2018-06-28', '2018-07-18', 15, 'hr', 16, 27, 5035, 'R'),
(574681247, 'antonio', 'ME3', 'AG1', '2018-07-18', '2018-07-19', '2018-07-22', '2018-07-20', 13, 'hr', 18, 3, 5473, 'R'),
(574681248, 'ethan', 'ME1', 'AG2', '2018-07-20', '2018-07-28', '2018-07-29', '2018-07-20', 10, 'hr', 21, 1, 690, 'R'),
(574681249, 'james', 'ME1', 'AG2', '2018-07-23', '2018-07-24', '2018-07-25', '2018-07-23', 10, 'hr', 5, 1, 5000, 'R'),
(574681250, 'lucas', 'ME3', 'AG2', '2018-07-23', '2018-07-23', '2018-07-24', '2018-07-23', 2600, 'days', NULL, 1, 2600, 'R'),
(574681251, 'james', 'ME10', 'AG1', '2018-07-23', '2018-07-25', '2018-07-30', '2018-07-23', 10, 'hr', 16, 2, 600, 'R'),
(574681252, 'christine', 'MA11', 'AG2', '2018-07-23', '2018-07-23', '2018-07-23', '2018-07-23', 13, 'hr', 20, 0, 2600, 'R'),
(574681253, 'christine', 'ME6', 'AG7', '2018-07-23', '2018-07-23', '2018-08-03', '2018-07-23', 2600, 'days', NULL, 11, 28600, 'R'),
(574681254, 'ethan', 'MA12', 'AG5', '2018-07-23', '2018-07-23', '2018-07-26', '2018-07-23', 3200, 'days', NULL, 3, 9600, 'R'),
(574681255, 'christine', 'ME8', 'AG5', '2018-07-23', '2018-07-23', '2018-08-08', '2018-07-23', 2400, 'days', NULL, 16, 38400, 'R'),
(574681257, 'james', 'ME7', 'AG4', '2018-08-11', '2018-08-13', '2018-08-17', NULL, 14, 'hr', NULL, NULL, NULL, 'NR'),
(574681258, 'lucas', 'ME3', 'AG1', '2021-03-24', '2021-03-24', '2021-03-25', '2021-03-24', 2600, 'days', NULL, 1, 2600, 'R'),
(574681259, 'lucas', 'ME5', 'AG8', '2021-03-24', '2021-03-24', '2021-03-26', '2021-03-24', 6100, 'days', NULL, 2, 12200, 'R');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
 ADD PRIMARY KEY (`tool_id`), ADD UNIQUE KEY `tool_id` (`tool_id`);

--
-- Indexes for table `clienttools`
--
ALTER TABLE `clienttools`
 ADD PRIMARY KEY (`tool_id`), ADD KEY `client_username` (`client_username`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
 ADD PRIMARY KEY (`client_username`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
 ADD PRIMARY KEY (`customer_username`);

--
-- Indexes for table `agent`
--
ALTER TABLE `agent`
 ADD PRIMARY KEY (`agent_id`), ADD UNIQUE KEY `agent_mailid` (`agent_mailid`), ADD KEY `client_username` (`client_username`);

--
-- Indexes for table `rentedtools`
--
ALTER TABLE `rentedtools`
 ADD PRIMARY KEY (`id`), ADD KEY `customer_username` (`customer_username`), ADD KEY `tool_id` (`tool_id`), ADD KEY `agent_id` (`agent_id`);

--
-- AUTO_INCREMENT for dumped tables
--

ALTER TABLE `rentedtools`
MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=574681260;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `clienttools`
--
ALTER TABLE `clienttools`
ADD CONSTRAINT `clientcars_ibfk_1` FOREIGN KEY (`client_username`) REFERENCES `clients` (`client_username`),
ADD CONSTRAINT `clientcars_ibfk_2` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`tool_id`);

--
-- Constraints for table `agent`
--
ALTER TABLE `agent`
ADD CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`client_username`) REFERENCES `clients` (`client_username`);


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
